salut,
Le nom de cette project est:"réalisation d'un interface de recherche documents textuels"
--------------------------------------------------------------------------------------------
MON GITHUB:https://github.com/BachirZahaf27/r-alisation-d-un-interface-de-recherche-documents-textuels
--------------------------------------------------------------------------------------------
la description de projet est dussu mais tu peu aussi trouver su GITHUB pour voir le image
---------------------------------------------------------------------------------------------
# realization-of-a-textual-documents-search-interface
this interface make you do 3 types of search on a number of  documents example (100 documents)

1)the first type of search is search by the name of the document :
for that, you can check the file search.java in the Repositories
you can check also this image before and after the search:

![name1](https://user-images.githubusercontent.com/61596276/114112088-e27c7880-98db-11eb-8f65-64b51dce0d76.png)
![name2](https://user-images.githubusercontent.com/61596276/114112130-0475fb00-98dc-11eb-9b80-8dc99687d1ca.png)


2)the second type of search is search by auteur:
for this, you can check the file finder.java in the Repositories
I made a connection between two table 
you can check also this image before and after the search:

![auteur1](https://user-images.githubusercontent.com/61596276/114112290-5e76c080-98dc-11eb-9c99-5b39c2aa8821.PNG)
![auteur2](https://user-images.githubusercontent.com/61596276/114112267-53239500-98dc-11eb-8321-b68b4281cb9a.PNG)


3)the third is search by word:

NOW FOR THE MOST IMPORTANT THING IN THIS PROJECT
Search by word 
we have to search for the word inside all the document and display them on a table 
for that, I try to do just like the first type of search and it works normally BUT the teacher says that is not the solution
SHE said that you have to index the documents and then you can search for the word 
so I search for some code and I find this solution below
https://github.com/chiragagrawal93/Lucene-Tutorials

BUT I DONT KNOW HOW TO ADD THIS FUNCTIONS TO MY CODE SO IT WILL WORK.
THE PROBLEM IS THAT I DON'T KNOW HOW I CAN  CALL THIS FUNCTIONS.

hopefully you understand my problem if not this is my email:bachir.zahaf27@gmail.com

thanks




in french:
# réalisation-d-un-interface-de-recherche-documents-textuels
cette interface vous fait faire 3 types de recherche sur un certain nombre d'exemples de documents (100 documents)

1) le premier type de recherche est la recherche par le nom du document:
pour cela, vous pouvez vérifier le fichier search.java dans les référentiels
vous pouvez également vérifier cette image avant et après la recherche

![name1](https://user-images.githubusercontent.com/61596276/114112088-e27c7880-98db-11eb-8f65-64b51dce0d76.png)
![name2](https://user-images.githubusercontent.com/61596276/114112130-0475fb00-98dc-11eb-9b80-8dc99687d1ca.png)

2) le deuxième type de recherche est la recherche par auteur:
pour cela, vous pouvez vérifier le fichier finder.java dans les référentiels
J'ai fait une connexion entre deux tables
vous pouvez également vérifier cette image avant et après la recherche

![auteur1](https://user-images.githubusercontent.com/61596276/114112290-5e76c080-98dc-11eb-9c99-5b39c2aa8821.PNG)
![auteur2](https://user-images.githubusercontent.com/61596276/114112267-53239500-98dc-11eb-8321-b68b4281cb9a.PNG)

3) la troisième est la recherche par mot:

MAINTENANT POUR LA CHOSE LA PLUS IMPORTANTE DE CE PROJET
Recherche par mot
nous devons rechercher le mot dans tout le document et les afficher sur un tableau
pour ça, j'essaye de faire comme le premier type de recherche et ça marche normalement MAIS l'enseignant dit que ce n'est pas la solution
ELLE a dit que vous devez indexer les documents et ensuite vous pouvez rechercher le mot
donc je recherche du code et je trouve cette solution ci-dessous
https://github.com/chiragagrawal93/Lucene-Tutorials

MAIS JE NE SAIS PAS COMMENT AJOUTER CES FONCTIONS À MON CODE POUR QUE CELA FONCTIONNE.
LE PROBLÈME EST QUE JE NE SAIS PAS COMMENT APPELER CES FONCTIONS.

j'espère que vous comprenez mon problème sinon c'est mon email: bachir.zahaf27@gmail.com

Merci
