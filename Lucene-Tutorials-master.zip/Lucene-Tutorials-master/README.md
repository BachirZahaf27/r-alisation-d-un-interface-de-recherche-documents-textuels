# Apache Lucene Video Tutorials
#####Link to watch videos - https://youtu.be/FixCCGjLWGg?list=PLPjq0_ZOyVPN5a6YBjkEhA8Vd5PXHdkQO

1. This repository contains the power point presentations showed in the video.<br />
    a. Apache Lucene Part 1.pptx <br />
    b. Apache Lucene Part 2.pptx<br />
    c. Apache Lucene Part 3.pptx<br />
    d. Apache Lucene Part 4.pptx<br /><br />
  These PPT's corresponds to the four videos shown in the video lecture series.<br /><br />
2. It also contains the codes that were shown in the video.<br />
    a. IndexFiles.java<br />
    b. SearchFIles.java<br />
  Link - https://github.com/chiragagrawal93/Lucene-Tutorials/tree/master/lucene/src/lucene<br /><br />
3. It also contains all the test data used for indexing.<br />
  Link - https://github.com/chiragagrawal93/Lucene-Tutorials/tree/master/test%20data<br /><br />
